package com.example.secondhandcar.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.secondhandcar.entity.Guanliyuan;
import org.apache.ibatis.annotations.Mapper;

/**
 * 管理员信息Mapper
 */
@Mapper
public interface GuanliyuanMapper extends BaseMapper<Guanliyuan> {

} 