package com.example.secondhandcar.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.secondhandcar.entity.Shoucang;
import org.apache.ibatis.annotations.Mapper;

/**
 * 收藏信息Mapper
 */
@Mapper
public interface ShoucangMapper extends BaseMapper<Shoucang> {

} 