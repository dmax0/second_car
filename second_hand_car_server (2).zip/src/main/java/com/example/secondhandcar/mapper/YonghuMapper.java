package com.example.secondhandcar.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.secondhandcar.entity.Yonghu;
import org.apache.ibatis.annotations.Mapper;

/**
 * 用户信息Mapper
 */
@Mapper
public interface YonghuMapper extends BaseMapper<Yonghu> {

} 