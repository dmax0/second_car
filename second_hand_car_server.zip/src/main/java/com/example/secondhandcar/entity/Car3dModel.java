package com.example.secondhandcar.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 车辆3D模型
 */
@Data
@TableName("car_3d_models")
@Schema(description = "车辆3D模型")
public class Car3dModel implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    @Schema(description = "主键ID")
    private Long id;

    @Schema(description = "创建时间")
    private Date addtime;

    @Schema(description = "汽车型号ID", required = true)
    private Long qichexinghaoid;

    @Schema(description = "模型名称", required = true)
    private String modelName;

    @Schema(description = "模型文件路径", required = true)
    private String modelFilePath;

    @Schema(description = "缩略图路径")
    private String thumbnailPath;

    @Schema(description = "模型版本")
    private String modelVersion = "1.0";

    @Schema(description = "多边形数量")
    private Integer polygonCount;

    @Schema(description = "纹理质量")
    private String textureQuality = "medium";

    @Schema(description = "是否包含内饰模型")
    private Boolean hasInterior = false;

    @Schema(description = "是否包含动画")
    private Boolean hasAnimations = false;

    @Schema(description = "模型比例因子")
    private Float modelScale = 1.0f;

    @Schema(description = "模型格式")
    private String modelFormat = "glb";

    @Schema(description = "默认位置")
    private String defaultPosition = "0,0,0";

    @Schema(description = "默认旋转")
    private String defaultRotation = "0,0,0";

    @Schema(description = "是否VR优化")
    private Boolean vrOptimized = false;

    @Schema(description = "移动版模型路径")
    private String mobileVersionPath;

    @Schema(description = "是否支持WebXR")
    private Boolean supportWebxr = true;
} 