package com.example.secondhandcar.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.secondhandcar.entity.Yonghu;
import com.example.secondhandcar.exception.ServiceException;
import com.example.secondhandcar.mapper.YonghuMapper;
import com.example.secondhandcar.service.YonghuService;
import com.example.secondhandcar.utils.JwtUtils;
import com.example.secondhandcar.vo.LoginVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.Date;

/**
 * 用户服务实现
 */
@Service
public class YonghuServiceImpl extends ServiceImpl<YonghuMapper, Yonghu> implements YonghuService {

    @Autowired
    private JwtUtils jwtUtils;

    @Override
    public LoginVO login(String username, String password) {
        // 查询用户
        Yonghu yonghu = getByUsername(username);
        if (yonghu == null) {
            throw new ServiceException("用户不存在");
        }

        // 验证密码
        if (!yonghu.getMima().equals(password)) {
            throw new ServiceException("密码错误");
        }

        // 检查用户状态
        if (!"active".equals(yonghu.getZhuangtai())) {
            throw new ServiceException("账号已被禁用");
        }

        // 构建登录结果
        return createLoginVO(yonghu);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Yonghu register(Yonghu yonghu) {
        // 校验用户名
        Yonghu existUser = getByUsername(yonghu.getYonghuming());
        if (existUser != null) {
            throw new ServiceException("用户名已存在");
        }

        // 校验手机号（如果有）
        if (StringUtils.hasText(yonghu.getShoujihao())) {
            existUser = getByPhone(yonghu.getShoujihao());
            if (existUser != null) {
                throw new ServiceException("手机号已被注册");
            }
        }

        // 设置默认值
        yonghu.setAddtime(new Date());
        if (yonghu.getYonghuType() == null) {
            yonghu.setYonghuType("user");
        }
        if (yonghu.getZhuangtai() == null) {
            yonghu.setZhuangtai("active");
        }

        // 保存用户
        save(yonghu);
        return yonghu;
    }

    @Override
    public IPage<Yonghu> listPage(Page<Yonghu> page, String yonghuming, String yonghuType, String zhuangtai) {
        LambdaQueryWrapper<Yonghu> queryWrapper = new LambdaQueryWrapper<>();
        if (StringUtils.hasText(yonghuming)) {
            queryWrapper.like(Yonghu::getYonghuming, yonghuming);
        }
        if (StringUtils.hasText(yonghuType)) {
            queryWrapper.eq(Yonghu::getYonghuType, yonghuType);
        }
        if (StringUtils.hasText(zhuangtai)) {
            queryWrapper.eq(Yonghu::getZhuangtai, zhuangtai);
        }
        queryWrapper.orderByDesc(Yonghu::getAddtime);
        return page(page, queryWrapper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateStatus(Long id, String zhuangtai) {
        Yonghu yonghu = getById(id);
        if (yonghu == null) {
            throw new ServiceException("用户不存在");
        }
        
        yonghu.setZhuangtai(zhuangtai);
        return updateById(yonghu);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean resetPassword(Long id, String newPassword) {
        Yonghu yonghu = getById(id);
        if (yonghu == null) {
            throw new ServiceException("用户不存在");
        }
        
        yonghu.setMima(newPassword);
        return updateById(yonghu);
    }

    @Override
    public Yonghu getByUsername(String yonghuming) {
        LambdaQueryWrapper<Yonghu> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Yonghu::getYonghuming, yonghuming);
        return getOne(queryWrapper);
    }

    @Override
    public Yonghu getByPhone(String shoujihao) {
        LambdaQueryWrapper<Yonghu> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Yonghu::getShoujihao, shoujihao);
        return getOne(queryWrapper);
    }

    /**
     * 创建登录响应对象
     */
    private LoginVO createLoginVO(Yonghu yonghu) {
        LoginVO loginVO = new LoginVO();
        loginVO.setId(yonghu.getId());
        loginVO.setUsername(yonghu.getYonghuming());
        loginVO.setUserType(yonghu.getYonghuType());
        loginVO.setAvatar(yonghu.getTouxiang());
        
        // 生成JWT令牌
        String token = jwtUtils.generateToken(yonghu.getYonghuming(), yonghu.getYonghuType(), yonghu.getId());
        loginVO.setToken(token);
        
        return loginVO;
    }
} 