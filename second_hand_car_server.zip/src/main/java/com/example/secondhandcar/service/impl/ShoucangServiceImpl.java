package com.example.secondhandcar.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.secondhandcar.entity.Shoucang;
import com.example.secondhandcar.exception.ServiceException;
import com.example.secondhandcar.mapper.ShoucangMapper;
import com.example.secondhandcar.service.ShoucangService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

/**
 * 收藏服务实现
 */
@Service
public class ShoucangServiceImpl extends ServiceImpl<ShoucangMapper, Shoucang> implements ShoucangService {

    @Autowired
    private ShoucangMapper shoucangMapper;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean add(Long userId, Long carId) {
        // 检查是否已收藏
        if (isCollected(userId, carId)) {
            throw new ServiceException("已收藏该车辆");
        }

        // 创建收藏
        Shoucang shoucang = new Shoucang();
        shoucang.setUserid(userId);
        shoucang.setRefid(carId);
        shoucang.setTablename("ershouche");
        shoucang.setAddtime(new Date());
        
        int result = shoucangMapper.insert(shoucang);
        return result > 0;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean cancel(Long userId, Long carId) {
        LambdaQueryWrapper<Shoucang> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Shoucang::getUserid, userId);
        queryWrapper.eq(Shoucang::getRefid, carId);
        queryWrapper.eq(Shoucang::getTablename, "ershouche");
        
        int result = shoucangMapper.delete(queryWrapper);
        return result > 0;
    }

    @Override
    public boolean isCollected(Long userId, Long carId) {
        LambdaQueryWrapper<Shoucang> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Shoucang::getUserid, userId);
        queryWrapper.eq(Shoucang::getRefid, carId);
        queryWrapper.eq(Shoucang::getTablename, "ershouche");
        
        return shoucangMapper.selectCount(queryWrapper) > 0;
    }
} 